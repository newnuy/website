=== Dewplayer ===
Contributors: Roya Khosravi
Donate link: http://www.royakhosravi.com/?p=3
Tags: Post, admin, posts, plugin, page, Dewplayer, flash player, Mp3 player, Dew player, Dew
Requires at least: 2.0.2
Tested up to: 2.6.2
Stable tag: 1.2

Dewplayer Wordpress plugin - Insert Dewplayer (Flash Mp3 Player) in posts/pages.

== Description ==

Dewplayer Wordpress plugin allows you to insert DewPlayer (a free flash mp3 Player, under Creative Commons licence) in posts or pages and lets you listen to your favorite MP3 songs online. 

Usage : 

Copy & Past this code into your post or page: 

[dewplayer:Path to your mp3 files on local or remote sites]. 

Multiple files are separated by a pipe (|).

Examples: 

[dewplayer:http://www.mymusic.com/mysong.mp3]

[dewplayer:/dir/mysong.mp3] 

[dewplayer:song1.mp3|song2.mp3|song3.mp3].

Configurable parameters : 

Version (Classic/Mini/Multi), Background color, transparency, Volume, Auto start, Auto replay (Loop), Random play...

Plugin Version : 

1.2 for Dewplayer 1.9

More About Dewplayer WordPress Plugin : 

http://www.royakhosravi.com/?p=3

More About Dewplayer : 

http://www.alsacreations.fr/dewplayer-en

== Installation ==

1. Download plugin and unzip.
2. Upload the plugin file to your WordPress plugins directory inside of wp-content : /wp-content/plugins/
3. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

Please visit the [Dewplayer plugin page](http://www.royakhosravi.com/?p=3) for screenshots & user examples.

== Screenshots ==

Please visit the [Dewplayer plugin page](http://www.royakhosravi.com/?p=3) for screenshots & user examples.