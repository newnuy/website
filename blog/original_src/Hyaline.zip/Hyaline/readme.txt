/*
Theme Name: Hyaline
Theme URI: http://edblog.net/
Description:  A 3 column theme. Design by Eduardo, This is first edition. Why version 1.05 ? It released on January 5, it's my birthday. :)
Version: 1.05.2
Author: Eduardo
Author URI: http://edblog.net/
Last Update: January 10th, 2007 
*/



Installtion:

  * Download the archive and extract
  * Upload 'Hyaline - 105' folder in /wp-content/themes/ folder of where your WordPress installed
  * Login to your WordPress administration panel, activate 'Hyaline - 105' theme in Presentation page

Theme:

  * Three-columm, Blue & White Style
  * For Internet Explorer & Firefox
  * Simplify Archive, Search and Category
  * WordPress 2.0 +
  * SEO Title 


2007/01/10 Update:

  * Modify CSS, Now support Safari and Opera
  * Fixed Page.php - Comments part