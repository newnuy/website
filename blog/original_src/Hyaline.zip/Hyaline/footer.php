
<hr />
<div id="footer">
	<p>
<a href="http://edblog.net/archives/517">Hyaline 1.05</a> &#183; <?php _e('Design by'); ?> <a href="http://edblog.net" title="<?php _e('Theme designed by'); ?> Eduardo">Eduardo</a>
 &#183; Powered By <a href="http://www.wordpress.org" target="_blank" alt="Blog Engine">WordPress</a> 
</p>

</div>
</div>

<?php get_sidebar(); ?>
<?php wp_footer(); ?>
</body>
</html>
